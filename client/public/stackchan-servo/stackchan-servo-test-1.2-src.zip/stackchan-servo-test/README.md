# StackChan head-servo freeze test

A small test program for the M5Stack StackChan (CoreS3 on the StackChan base). It moves the head, shows on the screen whether each servo still answers on its bus, and logs every second to a CSV file.

It exists to document one fault: on one unit, both head servos stop answering and stop moving at the same moment, and stay that way until servo power is switched off and on.

## What it runs

- Head motion goes through `M5StackChan.Motion.move()` and nothing else.
- Libraries: M5Unified 0.2.29, M5GFX 0.2.36, StackChan-BSP at commit `8d4d6fc`. All from M5Stack.
- No WiFi, audio, LEDs or camera.

## Motion

Every 3 seconds the head is sent to a new random pose at BSP speed 400.

| Axis | Range | Notes |
|---|---|---|
| Yaw | ±60° | |
| Pitch | raw 668 to 780 | 15° to 50° above the BSP's default pitch zero (620) |

Pitch is given as a raw servo position so it lands in the same place whatever zero is stored in NVS.

## How a freeze is detected

Both servos are pinged every 500 ms. Their position, load, voltage, temperature and moving flag are read once a second.

The reads use a second handle on the servo UART. Each one holds the BSP's own Motion mutex, so it never overlaps the BSP's 50 Hz motion task.

A servo that gives no reply to two probes in a row (about 1 second) counts as not responding. Each probe retries its ping once.

## What happens during a freeze

1. The status box turns red: `SERVOS NOT RESPONDING`, with the freeze number and the test time it started.
2. Move commands keep being sent. The CoreS3 and the screen keep running.
3. After 30 seconds, or on a screen tap, the program switches servo power off for 500 ms and on again (`M5StackChan.setServoPowerEnabled`).
4. If both servos answer again, the box shows `RECOVERED` with how long they were out. If they come back on their own first, it says so.

## Screen

| Area | Shows |
|---|---|
| Top bar | Program version; wall clock, once set |
| `T+ mm:ss` | Time since the test started |
| `freezes: N` | Freezes so far in this run |
| Status box | Blue: waiting to start. Green: servos OK. Red: not responding. |
| YAW / PITCH lines | Reply status, position, voltage, temperature, load |
| Battery line | Base battery voltage and current (INA226), USB voltage |
| `last shutdown` | Waiting screen only: why the unit last switched off, read from the power chip |
| Bottom line | Library versions, run number, whether the log is on |

## Log

The log is `/servotest.csv` on the CoreS3's LittleFS partition. Each run appends to it.

There is one `tick` row a second, plus a row for each event: `START`, `FREEZE`, `POWER_CYCLE`, `RECOVER`, `STILL_FROZEN`.

| Column | Meaning |
|---|---|
| `run` | Run number, counts up on every start |
| `test_ms` | Milliseconds since the test started |
| `clock` | Wall clock, empty until set |
| `event`, `state` | Row type and test state |
| `cmd_yaw_deg10`, `cmd_pitch_raw` | The pose last commanded |
| `*_reply` | 1 if the servo answered its last ping |
| `*_pos`, `*_load`, `*_volt10`, `*_temp`, `*_moving`, `*_status` | The servo's own registers; empty while it isn't answering |
| `*_err` | The driver's error code for a failed ping |
| `batt_v`, `batt_a`, `vbus_mv` | Base battery and USB input |
| `freezes` | Freezes so far in this run |
| `note` | Detail for event rows |

The `START` row's note also records how the unit last switched on and off: `on_src` and `off_src` are the power chip's (AXP2101) registers 0x20 and 0x21 as read at boot, and `reset` is the ESP32's reset reason. An `off_src` of `08` means the power chip shut the unit down because the system voltage fell too low; `01` or `04` is the power button.

## Charging

While the blue waiting screen is up, the program switches the CoreS3's 5 V output off (`M5.Power.setExtOutput(false)`). On the unit this was written for, USB power does not reach the charger while that output is on, so the battery drains even when plugged in. Starting the test switches the output back on, which is the state `M5.begin()` leaves it in.

The waiting screen shows the battery voltage and the charging current.

## Build and flash

```bash
pio run -t upload
```

`servotest.py` sends the serial commands and saves the log:

```bash
python servotest.py /dev/cu.usbmodem1101 dump servotest.csv
```

## Controls

| Input | Action |
|---|---|
| Screen tap | Start the test. During a freeze: cycle servo power now. |
| Serial `s` | Start the test |
| Serial `d` | Print the log |
| Serial `x` | Delete the log |
| Serial `T2026-11-11 14:05:00` | Set the clock |
| Serial `p` | Print battery, USB and power-chip state, with the last switch-on and switch-off reasons |
| Serial `e0` / `e1` | Switch the 5 V output off / on |

Serial is 115200 baud over the CoreS3's USB port.
