#!/usr/bin/env python3
"""Talk to the servo test over USB serial.

  servotest.py PORT clock          set the unit's clock from this computer
  servotest.py PORT start          start the test
  servotest.py PORT dump FILE      save the log to FILE
  servotest.py PORT delete         delete the log on the unit
  servotest.py PORT power          print battery, USB and power-chip state
  servotest.py PORT watch [SECS]   print what the unit sends (default 10 s)

Needs pyserial. PlatformIO's Python has it: ~/.platformio/penv/bin/python
"""
import sys
import time

import serial


def open_port(port):
    # DTR high or the CoreS3 sends nothing back; RTS low so it isn't reset
    s = serial.Serial()
    s.port = port
    s.baudrate = 115200
    s.timeout = 0.2
    s.dtr = True
    s.rts = False
    s.open()
    time.sleep(0.3)
    s.reset_input_buffer()
    return s


def read_for(s, seconds):
    out = b""
    end = time.time() + seconds
    while time.time() < end:
        out += s.read(4096)
    return out.decode("utf-8", "replace")


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    port, cmd = sys.argv[1], sys.argv[2]
    s = open_port(port)
    if cmd == "clock":
        s.write(time.strftime("T%Y-%m-%d %H:%M:%S\n").encode())
        print(read_for(s, 1.5).strip())
    elif cmd == "start":
        s.write(b"s\n")
        print(read_for(s, 3).strip())
    elif cmd == "delete":
        s.write(b"x\n")
        print(read_for(s, 1.5).strip())
    elif cmd == "power":
        s.write(b"p\n")
        print(read_for(s, 1.5).strip())
    elif cmd == "watch":
        print(read_for(s, float(sys.argv[3]) if len(sys.argv) > 3 else 10).strip())
    elif cmd == "dump":
        s.write(b"d\n")
        text, end = "", time.time() + 120
        while "-----END servotest.csv-----" not in text and time.time() < end:
            text += s.read(65536).decode("utf-8", "replace")
        if "-----BEGIN servotest.csv-----" not in text or "-----END servotest.csv-----" not in text:
            sys.exit("no complete log received")
        body = text.split("-----BEGIN servotest.csv-----", 1)[1].split("-----END servotest.csv-----", 1)[0]
        # tick rows printed live during the dump are not part of the file
        rows = [r for r in body.replace("\r", "").split("\n") if r]
        with open(sys.argv[3], "w") as f:
            f.write("\n".join(rows) + "\n")
        print(f"{len(rows)} lines saved to {sys.argv[3]}")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
