// StackChan head-servo freeze test
//
// Moves the head with M5StackChan.Motion.move() and nothing else, and shows on
// the screen whether each servo still answers on its bus. When the servos stop
// answering it says so in red, keeps sending moves, and after 30 s (or a tap on
// the screen) switches servo power off and on again. Every second goes into a
// CSV log on the CoreS3's flash.
//
// No WiFi, no audio, no LEDs, no camera. Libraries: M5Unified, M5GFX and
// StackChan-BSP, at the versions pinned in platformio.ini.
//
// Screen tap     start the test; during a freeze, cycle servo power now
// Serial 's'     start the test
// Serial 'd'     print the log
// Serial 'x'     delete the log
// Serial 'T2026-11-11 14:05:00'   set the clock
// Serial 'p'     print battery, USB and power-chip state
// Serial 'e0'/'e1' switch the 5 V output off/on

#include <Arduino.h>
#include <M5StackChan.h>
#include <drivers/FTServo_Arduino/src/SCSCL.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <mutex>

#define TEST_VERSION   "1.2"
#define LIB_VERSIONS   "M5Unified 0.2.29  StackChan-BSP 8d4d6fc"
#define LOG_PATH       "/servotest.csv"

// ---- Head motion -----------------------------------------------------------
// Yaw swings 60 degrees either side of centre. Pitch is given as a raw servo
// position so it lands in the same place whatever zero is stored in NVS:
// 668..780 is 15..50 degrees above the BSP's default pitch zero (620), well
// inside the 5..85 degree range M5 documents and clear of both end stops.
#define YAW_RANGE          600     // tenths of a degree
#define PITCH_RAW_MIN      668
#define PITCH_RAW_MAX      780
#define PITCH_ZERO_DEFAULT 620     // the BSP's default
#define MOVE_EVERY_MS      3000
#define MOVE_SPEED         400     // BSP speed, 0..1000

// ---- Freeze handling -------------------------------------------------------
#define PROBE_MS             500   // ping both servos this often
#define FAILS_TO_FREEZE      2     // probes in a row with no reply
#define POWER_CYCLE_AFTER_MS 30000 // leave a freeze alone this long first
#define RECOVERED_BANNER_MS  15000
#define LOG_EVERY_MS         1000

// ---- Servo bus access ------------------------------------------------------
// The BSP keeps its bus object and Motion's mutex private. To read a servo's
// registers without colliding with the BSP's 50 Hz motion task, this opens a
// second handle on the same UART and holds the BSP's own mutex for every
// transaction. An explicit template instantiation is allowed to name a private
// member, which is how the mutex is reached without changing the BSP.
template <typename Tag, typename Tag::type M>
struct PrivateMember { friend typename Tag::type get(Tag) { return M; } };
struct MotionMutexTag {
  typedef std::mutex stackchan::motion::Motion::*type;
  friend type get(MotionMutexTag);
};
template struct PrivateMember<MotionMutexTag, &stackchan::motion::Motion::_mutex>;

struct BusLock {
  std::lock_guard<std::mutex> g;
  BusLock() : g(M5StackChan.Motion.*get(MotionMutexTag())) {}
};

static SCSCL probeBus;

struct ServoView {
  uint8_t id;
  const char* name;
  bool ok = true;            // false after FAILS_TO_FREEZE probes with no reply
  uint8_t fails = 0;
  uint32_t firstFailMs = 0;
  int commErr = 0;           // driver's error for the last failed ping
  int status = 0;            // the servo's own status byte
  int pos = -1, load = 0, volt = -1, temp = -1, moving = -1;
};
static ServoView yaw   = {1, "YAW"};
static ServoView pitch = {2, "PITCH"};

static void probe(ServoView& s, bool full) {
  BusLock lock;
  bool replied = probeBus.Ping(s.id) == s.id;
  if (!replied) {
    s.commErr = probeBus.getLastError();
    delay(2);
    replied = probeBus.Ping(s.id) == s.id;
  }
  if (!replied) {
    if (s.fails == 0) s.firstFailMs = millis();
    if (s.fails < 255) s.fails++;
    if (s.fails >= FAILS_TO_FREEZE) s.ok = false;
    return;
  }
  s.fails = 0;
  s.ok = true;
  s.commErr = 0;
  s.status = probeBus.getState();
  if (full) {
    s.pos    = probeBus.ReadPos(s.id);
    s.load   = probeBus.ReadLoad(s.id);
    s.volt   = probeBus.ReadVoltage(s.id);   // tenths of a volt
    s.temp   = probeBus.ReadTemper(s.id);
    s.moving = probeBus.ReadMove(s.id);
  }
}

// ---- Test state ------------------------------------------------------------
enum State : uint8_t { IDLE, RUNNING, FROZEN };
static State state = IDLE;
static const char* stateName() { return state == IDLE ? "IDLE" : state == RUNNING ? "RUNNING" : "FROZEN"; }

static uint32_t runNumber = 0;
static uint32_t testStartMs = 0;
static uint32_t lastMoveMs = 0, lastProbeMs = 0, lastLogMs = 0, lastDrawMs = 0;
static uint32_t probeCount = 0;
static int cmdYaw = 0, cmdPitchRaw = PITCH_RAW_MIN, pitchZero = PITCH_ZERO_DEFAULT;

static uint16_t freezeCount = 0;
static uint32_t freezeStartMs = 0;      // first probe with no reply
static uint32_t freezeHoldMs = 0;       // when the 30 s wait started
static bool     freezeYaw = false, freezePitch = false;
static uint32_t recoveredAtMs = 0;      // green banner timer, 0 = none
static uint32_t lastOutMs = 0;
static uint32_t lastFreezeAtS = 0;
static const char* lastRecovery = "";

// Why the unit last switched on and off, read from the power chip at boot
// (AXP2101 registers 0x20 and 0x21), and the ESP32's own reset reason.
static uint8_t bootOnSrc = 0, bootOffSrc = 0;
static int     bootReset = 0;

static File logFile;
static bool logOk = false;
static M5Canvas canvas(&M5.Display);

static uint32_t testSeconds(uint32_t ms) { return testStartMs ? (ms - testStartMs) / 1000 : 0; }

static void clockNow(char* out, size_t n) {
  m5::rtc_datetime_t dt;
  if (M5.Rtc.isEnabled() && M5.Rtc.getDateTime(&dt) && dt.date.year >= 2026)
    snprintf(out, n, "%04d-%02d-%02d %02d:%02d:%02d", dt.date.year, dt.date.month, dt.date.date,
             dt.time.hours, dt.time.minutes, dt.time.seconds);
  else out[0] = 0;
}

// ---- Log -------------------------------------------------------------------
static const char* LOG_HEADER =
  "run,test_ms,clock,event,state,cmd_yaw_deg10,cmd_pitch_raw,"
  "yaw_reply,yaw_pos,yaw_load,yaw_volt10,yaw_temp,yaw_moving,yaw_status,yaw_err,"
  "pitch_reply,pitch_pos,pitch_load,pitch_volt10,pitch_temp,pitch_moving,pitch_status,pitch_err,"
  "batt_v,batt_a,vbus_mv,freezes,note";

static int servoCols(char* out, size_t n, const ServoView& s) {
  // A servo that isn't answering has no readings: leave them empty, not stale
  if (s.fails) return snprintf(out, n, "0,,,,,,,%d", s.commErr);
  return snprintf(out, n, "1,%d,%d,%d,%d,%d,%d,0", s.pos, s.load, s.volt, s.temp, s.moving, s.status);
}

static void logRow(const char* event, const char* note = "") {
  char clock[24], y[64], p[64], line[320];
  clockNow(clock, sizeof(clock));
  servoCols(y, sizeof(y), yaw);
  servoCols(p, sizeof(p), pitch);
  snprintf(line, sizeof(line), "%lu,%lu,%s,%s,%s,%d,%d,%s,%s,%.3f,%.3f,%d,%u,%s",
           (unsigned long)runNumber, (unsigned long)(testStartMs ? millis() - testStartMs : 0), clock, event,
           stateName(), cmdYaw, cmdPitchRaw, y, p,
           M5StackChan.getBatteryVoltage(), M5StackChan.getBatteryCurrent(), (int)M5.Power.getVBUSVoltage(),
           freezeCount, note);
  Serial.println(line);
  if (logFile) {
    logFile.println(line);
    logFile.flush();
  }
}

static void dumpLog() {
  if (logFile) logFile.flush();
  File f = LittleFS.open(LOG_PATH, "r");
  Serial.println("-----BEGIN servotest.csv-----");
  while (f && f.available()) Serial.write(f.read());
  Serial.println("-----END servotest.csv-----");
  if (f) f.close();
}

// ---- Screen ----------------------------------------------------------------
static void text(const char* s, int x, int y, const lgfx::IFont* font, uint16_t color, uint8_t datum = TL_DATUM) {
  canvas.setFont(font);
  canvas.setTextDatum(datum);
  canvas.setTextColor(color);
  canvas.drawString(s, x, y);
}

static void servoLine(const ServoView& s, int y) {
  char line[64];
  if (s.fails)
    snprintf(line, sizeof(line), "%-5s id%d  NO REPLY", s.name, s.id);
  else
    snprintf(line, sizeof(line), "%-5s id%d  reply OK  pos %d  %.1f V  %d C  load %d", s.name, s.id, s.pos,
             s.volt / 10.0f, s.temp, s.load);
  text(line, 8, y, &fonts::DejaVu12, s.fails ? TFT_RED : TFT_WHITE);
}

static void draw() {
  uint32_t now = millis();
  char line[80], clock[24];
  canvas.fillScreen(TFT_BLACK);

  // Header: what this is, and the wall clock when it has been set
  canvas.fillRect(0, 0, 320, 22, 0x2104);
  text("StackChan servo test " TEST_VERSION, 8, 5, &fonts::DejaVu12, TFT_WHITE);
  clockNow(clock, sizeof(clock));
  text(clock[0] ? clock + 5 : "clock not set", 312, 5, &fonts::DejaVu12, TFT_WHITE, TR_DATUM);

  // Test time and freeze count
  uint32_t t = testSeconds(now);
  snprintf(line, sizeof(line), "T+ %02lu:%02lu", (unsigned long)(t / 60), (unsigned long)(t % 60));
  text(line, 8, 28, &fonts::DejaVu24, TFT_WHITE);
  snprintf(line, sizeof(line), "freezes: %u", freezeCount);
  text(line, 312, 28, &fonts::DejaVu24, freezeCount ? TFT_ORANGE : TFT_WHITE, TR_DATUM);

  // Status box
  bool recovered = recoveredAtMs && now - recoveredAtMs < RECOVERED_BANNER_MS;
  uint16_t box = state == IDLE ? 0x0293 : state == FROZEN ? 0xD000 : recovered ? 0x0450 : 0x0320;
  canvas.fillRoundRect(6, 60, 308, 72, 8, box);
  if (state == IDLE) {
    text("TAP SCREEN TO START", 160, 78, &fonts::DejaVu24, TFT_WHITE, MC_DATUM);
    snprintf(line, sizeof(line), "yaw %s   pitch %s", yaw.fails ? "NO REPLY" : "reply OK", pitch.fails ? "NO REPLY" : "reply OK");
    text(line, 160, 102, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
    float amps = M5StackChan.getBatteryCurrent();   // negative while charging
    if (amps < -0.02f) snprintf(line, sizeof(line), "charging at %.2f A, %.2f V", -amps, M5StackChan.getBatteryVoltage());
    else               snprintf(line, sizeof(line), "not charging, %.2f V", M5StackChan.getBatteryVoltage());
    text(line, 160, 119, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
  } else if (state == FROZEN) {
    text("SERVOS NOT RESPONDING", 160, 78, &fonts::DejaVu18, TFT_WHITE, MC_DATUM);
    uint32_t f = testSeconds(freezeStartMs);
    snprintf(line, sizeof(line), "#%u  since T+%02lu:%02lu  (%lu s)  moves still sent", freezeCount,
             (unsigned long)(f / 60), (unsigned long)(f % 60), (unsigned long)((now - freezeStartMs) / 1000));
    text(line, 160, 100, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
    long left = ((long)POWER_CYCLE_AFTER_MS - (long)(now - freezeHoldMs)) / 1000;
    snprintf(line, sizeof(line), "servo power cycle in %ld s (tap = now)", left < 0 ? 0 : left);
    text(line, 160, 118, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
  } else if (recovered) {
    snprintf(line, sizeof(line), "RECOVERED #%u", freezeCount);
    text(line, 160, 80, &fonts::DejaVu24, TFT_WHITE, MC_DATUM);
    snprintf(line, sizeof(line), "%s, not responding for %.1f s", lastRecovery, lastOutMs / 1000.0f);
    text(line, 160, 112, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
  } else {
    text("SERVOS OK", 160, 80, &fonts::DejaVu24, TFT_WHITE, MC_DATUM);
    snprintf(line, sizeof(line), "moving to yaw %+.0f deg, pitch raw %d", cmdYaw / 10.0f, cmdPitchRaw);
    text(line, 160, 112, &fonts::DejaVu12, TFT_WHITE, MC_DATUM);
  }

  servoLine(yaw, 140);
  servoLine(pitch, 158);

  int vbus = M5.Power.getVBUSVoltage();
  if (vbus > 1000) snprintf(clock, sizeof(clock), "USB %.1f V", vbus / 1000.0f);
  else             snprintf(clock, sizeof(clock), "USB unplugged");
  snprintf(line, sizeof(line), "battery %.2f V  %.2f A   %s", M5StackChan.getBatteryVoltage(),
           M5StackChan.getBatteryCurrent(), clock);
  text(line, 8, 180, &fonts::DejaVu12, TFT_WHITE);

  if (state == IDLE) {
    // Why the unit last switched off, from the power chip (AXP2101 register 0x21)
    const char* why = bootOffSrc & 0x08 ? "power chip: system voltage too low"
                    : bootOffSrc & 0x80 ? "power chip: over temperature"
                    : bootOffSrc & 0x60 ? "power chip: regulator fault"
                    : bootOffSrc & 0x10 ? "power chip: USB over voltage"
                    : bootOffSrc & 0x05 ? "power button"
                    : bootOffSrc & 0x02 ? "software"
                    : "not recorded";
    snprintf(line, sizeof(line), "last shutdown: %s", why);
    text(line, 8, 198, &fonts::DejaVu12, bootOffSrc & 0xF8 ? TFT_ORANGE : TFT_WHITE);
  } else if (freezeCount && state != FROZEN) {
    snprintf(line, sizeof(line), "last: #%u at T+%02lu:%02lu, %.1f s, %s", freezeCount, (unsigned long)(lastFreezeAtS / 60),
             (unsigned long)(lastFreezeAtS % 60), lastOutMs / 1000.0f, lastRecovery);
    text(line, 8, 198, &fonts::DejaVu12, TFT_ORANGE);
  }

  snprintf(line, sizeof(line), LIB_VERSIONS "  run %lu  %s", (unsigned long)runNumber, logOk ? "log on" : "NO LOG");
  text(line, 8, 222, &fonts::DejaVu9, 0x8410);
  canvas.pushSprite(0, 0);
}

// ---- Test ------------------------------------------------------------------
static void startTest() {
  Preferences p;
  p.begin("servotest", false);
  runNumber = p.getUInt("run", 0) + 1;
  p.putUInt("run", runNumber);
  p.end();

  if (logOk) {
    bool fresh = !LittleFS.exists(LOG_PATH);
    logFile = LittleFS.open(LOG_PATH, "a");
    if (logFile && fresh) logFile.println(LOG_HEADER);
  }
  Serial.println(LOG_HEADER);

  M5.Power.setExtOutput(true);   // M5's default: the state M5.begin() leaves it in

  testStartMs = millis();
  lastMoveMs = testStartMs - MOVE_EVERY_MS;   // first move straight away
  state = RUNNING;
  char note[128];
  snprintf(note, sizeof(note), "test " TEST_VERSION " " LIB_VERSIONS " pitch_zero %d on_src %02X off_src %02X reset %d",
           pitchZero, bootOnSrc, bootOffSrc, bootReset);
  logRow("START", note);
}

static void enterFrozen(uint32_t now) {
  state = FROZEN;
  freezeCount++;
  recoveredAtMs = 0;
  freezeStartMs = now;
  if (!yaw.ok && yaw.firstFailMs < freezeStartMs) freezeStartMs = yaw.firstFailMs;
  if (!pitch.ok && pitch.firstFailMs < freezeStartMs) freezeStartMs = pitch.firstFailMs;
  freezeHoldMs = now;
  freezeYaw = !yaw.ok;
  freezePitch = !pitch.ok;
  lastFreezeAtS = testSeconds(freezeStartMs);
  logRow("FREEZE", "no reply to ping");
}

static void leaveFrozen(const char* how) {
  state = RUNNING;
  lastRecovery = how;
  lastOutMs = millis() - freezeStartMs;
  recoveredAtMs = millis();
  char note[96];
  snprintf(note, sizeof(note), "%s; out %lu ms; no reply from %s", how, (unsigned long)lastOutMs,
           freezeYaw && freezePitch ? "yaw+pitch" : freezeYaw ? "yaw" : "pitch");
  logRow("RECOVER", note);
}

static void powerCycleServos(const char* why) {
  logRow("POWER_CYCLE", why);
  M5StackChan.setServoPowerEnabled(false);
  delay(500);
  M5StackChan.setServoPowerEnabled(true);
  uint32_t t0 = millis();
  while (millis() - t0 < 5000) {
    delay(100);
    probe(yaw, false);
    probe(pitch, false);
    if (!yaw.fails && !pitch.fails) {
      probe(yaw, true);
      probe(pitch, true);
      leaveFrozen("servo power cycle");
      return;
    }
  }
  freezeHoldMs = millis();   // still dead: wait and cycle again
  logRow("STILL_FROZEN", "no reply 5 s after the power cycle");
}

static void handleSerial(bool& startReq) {
  static char buf[40];
  static uint8_t len = 0;
  while (Serial.available()) {
    char c = Serial.read();
    if (c != '\n' && c != '\r') {
      if (len < sizeof(buf) - 1) buf[len++] = c;
      continue;
    }
    buf[len] = 0;
    len = 0;
    if (buf[0] == 's') startReq = true;
    else if (buf[0] == 'p') {
      // Power state: base battery (INA226), USB input, and the CoreS3's own chips
      Serial.printf("batt %.3f V %.3f A  vbus %d mV  charging %d  level %d  axp[00]=%02X axp[01]=%02X  aw[02]=%02X aw[03]=%02X  boot: on_src %02X off_src %02X reset %d  now: axp[20]=%02X axp[21]=%02X\n",
                    M5StackChan.getBatteryVoltage(), M5StackChan.getBatteryCurrent(), (int)M5.Power.getVBUSVoltage(),
                    (int)M5.Power.isCharging(), (int)M5.Power.getBatteryLevel(),
                    M5.In_I2C.readRegister8(0x34, 0x00, 400000), M5.In_I2C.readRegister8(0x34, 0x01, 400000),
                    M5.In_I2C.readRegister8(0x58, 0x02, 400000), M5.In_I2C.readRegister8(0x58, 0x03, 400000),
                    bootOnSrc, bootOffSrc, bootReset,
                    M5.In_I2C.readRegister8(0x34, 0x20, 400000), M5.In_I2C.readRegister8(0x34, 0x21, 400000));
    } else if (buf[0] == 'e') {
      M5.Power.setExtOutput(buf[1] == '1');
      Serial.printf("5V output %s\n", buf[1] == '1' ? "on" : "off");
    }
    else if (buf[0] == 'd') dumpLog();
    else if (buf[0] == 'x') {
      if (logFile) logFile.close();
      LittleFS.remove(LOG_PATH);
      Serial.println("log deleted");
    } else if (buf[0] == 'T') {
      struct tm t = {};
      if (sscanf(buf + 1, "%d-%d-%d %d:%d:%d", &t.tm_year, &t.tm_mon, &t.tm_mday, &t.tm_hour, &t.tm_min, &t.tm_sec) == 6) {
        t.tm_year -= 1900;
        t.tm_mon -= 1;
        M5.Rtc.setDateTime(&t);
        Serial.println("clock set");
      }
    }
  }
}

void setup() {
  M5StackChan.begin();
  Serial.begin(115200);

  bootOnSrc  = M5.In_I2C.readRegister8(0x34, 0x20, 400000);
  bootOffSrc = M5.In_I2C.readRegister8(0x34, 0x21, 400000);
  bootReset  = (int)esp_reset_reason();

  probeBus.uart_num = UART_NUM_1;   // the BSP installed the driver; share it
  probeBus.IOTimeOut = 10;

  Preferences p;
  p.begin("servo", true);            // the BSP's own calibration store
  pitchZero = p.getInt("zero_pos_2", PITCH_ZERO_DEFAULT);
  p.end();

  logOk = LittleFS.begin(false);     // never format: the unit's own files live here too

  // While waiting to start, switch the CoreS3's 5 V output off so the battery
  // can charge: on the unit this was written for, USB power does not reach the
  // charger while that output is on. startTest() puts it back to M5's default.
  M5.Power.setExtOutput(false);

  canvas.setPsram(true);
  canvas.setColorDepth(16);
  canvas.createSprite(320, 240);
  M5.Display.setBrightness(160);
}

void loop() {
  M5StackChan.update();
  bool startReq = false;
  handleSerial(startReq);
  bool tapped = M5.Touch.getCount() > 0 && M5.Touch.getDetail().wasPressed();
  uint32_t now = millis();

  if (now - lastProbeMs >= PROBE_MS) {
    lastProbeMs = now;
    bool full = (probeCount++ % 2) == 0;   // registers once a second
    probe(yaw, full);
    probe(pitch, full);

    if (state == RUNNING && (!yaw.ok || !pitch.ok)) enterFrozen(now);
    else if (state == FROZEN) {
      freezeYaw |= !yaw.ok;
      freezePitch |= !pitch.ok;
      if (!yaw.fails && !pitch.fails) leaveFrozen("came back by itself");
    }
  }

  if (state == IDLE) {
    if (tapped || startReq) startTest();
  } else {
    // The head keeps being told to move, frozen or not
    if (now - lastMoveMs >= MOVE_EVERY_MS) {
      lastMoveMs = now;
      cmdYaw = (int)(esp_random() % (2 * YAW_RANGE + 1)) - YAW_RANGE;
      cmdPitchRaw = PITCH_RAW_MIN + (int)(esp_random() % (PITCH_RAW_MAX - PITCH_RAW_MIN + 1));
      M5StackChan.Motion.move(cmdYaw, (cmdPitchRaw - pitchZero) * 50 / 16, MOVE_SPEED);
    }
    if (state == FROZEN) {
      if (tapped) powerCycleServos("screen tap");
      else if (millis() - freezeHoldMs >= POWER_CYCLE_AFTER_MS) powerCycleServos("30 s timer");
    }
    if (millis() - lastLogMs >= LOG_EVERY_MS) {
      lastLogMs = millis();
      logRow("tick");
    }
  }

  if (millis() - lastDrawMs >= 200) {
    lastDrawMs = millis();
    draw();
  }
  delay(5);
}
